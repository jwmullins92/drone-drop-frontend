import React from 'react'


export default function NotFound() {
    return (
        <h1 className="card-text">PAGE NOT FOUND</h1>
    )
}